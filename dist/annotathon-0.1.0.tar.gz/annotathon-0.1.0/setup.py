# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['annotathon',
 'annotathon.annotation',
 'annotathon.parsing',
 'annotathon.utils']

package_data = \
{'': ['*']}

install_requires = \
['biopython>=1.78,<2.0',
 'entrezpy>=2.1.1,<3.0.0',
 'ete3>=3.1.2,<4.0.0',
 'ipywidgets>=7.5.1,<8.0.0',
 'matplotlib>=3.3.2,<4.0.0',
 'pandas-read-xml>=0.0.8,<0.0.9',
 'pandas>=1.1.2,<2.0.0',
 'requests>=2.25.0,<3.0.0',
 'sacred>=0.8.1,<0.9.0',
 'toml>=0.10.2,<0.11.0',
 'xmltodict>=0.12.0,<0.13.0',
 'xmltramp2>=3.1.1,<4.0.0']

setup_kwargs = {
    'name': 'annotathon',
    'version': '0.1.0',
    'description': 'Tools and Workflows for The Annotathon Project',
    'long_description': None,
    'author': 'Gustavo Magaña López',
    'author_email': 'gustavo.magana-lopez@u-psud.fr',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
